import sqlite3
import csv

conn = sqlite3.connect("data.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    description TEXT,
    link TEXT
)
""")

with open("sample_data.csv", newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        cursor.execute("INSERT INTO channels (name, description, link) VALUES (?, ?, ?)",
                       (row["name"], row["description"], row["link"]))

conn.commit()
conn.close()
print("✅ 数据库初始化完成")
