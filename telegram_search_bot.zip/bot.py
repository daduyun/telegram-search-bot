import sqlite3
from pyrogram import Client, filters
from pyrogram.types import Message

API_ID = 12345678  # 替换为你的 API_ID
API_HASH = "your_api_hash"  # 替换为你的 API_HASH
BOT_TOKEN = "your_bot_token"  # 替换为你的 Bot Token

app = Client("search-bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)
DB_PATH = "data.db"

def search_channels(keyword: str, limit: int = 5):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT name, link FROM channels
        WHERE name LIKE ? OR description LIKE ?
        LIMIT ?
    """, (f"%{keyword}%", f"%{keyword}%", limit))
    results = cursor.fetchall()
    conn.close()
    return results

@app.on_message(filters.command("start"))
async def start(_, message: Message):
    await message.reply("欢迎使用中文频道搜索机器人！请输入 /search 关键词 开始使用。")

@app.on_message(filters.command("search"))
async def search(_, message: Message):
    if len(message.command) < 2:
        await message.reply("❗️请输入关键词，例如 /search chatgpt")
        return

    keyword = " ".join(message.command[1:])
    results = search_channels(keyword)

    if not results:
        await message.reply("未找到匹配的频道 😢")
        return

    response = "🔍 搜索结果：\n"
    for i, (name, link) in enumerate(results, 1):
        response += f"{i}. [{name}]({link})\n"

    await message.reply(response, disable_web_page_preview=True)

app.run()
